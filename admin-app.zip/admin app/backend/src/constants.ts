export const DB_NAME = "AdminApp";
export const cookieOptions = {
  httpOnly: true,
  secure: true,
};
